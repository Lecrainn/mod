const keys = {
    "token": "OTM2MzI1NjU2MzA2OTA5MjI0.YfLjOA.lwyuJ9ceSExmlWgVrhiDkBbqRRA",
    "mongoose": "mongodb+srv://LecrainnPublic:berbe321!@cluster0.uxpgi.mongodb.net/myFirstDatabase?retryWrites=true&w=majority",
    "hookLogs":{
    "discordUserLogID": "",
    "discordUserLogToken": "",
    "voiceLogID": "",
    "voiceLogToken": "",
    "messageLogID": "",
    "messageLogToken": "",
    "boostLogID": "",
    "boostLogToken": "",
    "commandLogID": "",
    "commandLogToken": "",
    "nameChangeLog": "",
    "nameChangeLogToken": ""
    }
};

module.exports = keys;
